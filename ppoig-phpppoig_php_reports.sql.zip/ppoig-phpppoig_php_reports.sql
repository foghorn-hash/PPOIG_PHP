-- phpMyAdmin SQL Dump
-- version 2.6.4-pl1
-- http://www.phpmyadmin.net
-- 
-- Palvelin: localhost
-- Luontiaika: 30.05.2006 klo 14:18
-- Palvelimen versio: 4.1.14
-- PHP:n versio: 4.4.0
-- 
-- Tietokanta: `ppoigphp`
-- 

-- --------------------------------------------------------

-- 

-- Rakenne taulukolle `ppoig_php_reports`

-- 

DROP TABLE IF EXISTS `ppoig_php_reports`;

CREATE TABLE `ppoig_php_reports` (
  `report_id` int(8) NOT NULL auto_increment,
  `file0` varchar(255) NOT NULL default '',
  `file1` varchar(255) NOT NULL default '',
  `user_ip` varchar(255) NOT NULL default '',
  `user_isp` varchar(255) NOT NULL default '',
  `usr_agent` varchar(255) NOT NULL default '',
  `date_and_time` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`report_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Vedostetaan dataa taulukosta `ppoig_php_reports`
--